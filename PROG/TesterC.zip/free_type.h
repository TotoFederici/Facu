#ifndef __FREE_TYPE_H__

#define __FREE_TYPE_H__

#include <stddef.h>

extern void (*const FREE_FUNC[])(void*);

/**
 * (1) Frees memory allocated for an integer, referenced by a void pointer (which the function takes as an argument).
 * Takes a void pointer and frees the memory allocated for the int it references.
 * My bro, it takes an arrow to an INTEGER, liberates it from its pain, no longer WASTING space in memory.
 * Bro...
 * bro
 * bruh





 * EDIT: OMG 10 likes thank you so much haha
 */
void freeint(void* ptr);

/**
 * Frees memory allocated for an float, referenced by a void pointer (which the function takes as an argument).
 */
void freefloat(void* ptr);

/**
 * Frees memory allocated for an str, referenced by a void pointer (which the function takes as an argument).
 */

void freestr(void* ptr);

/**
 * Frees memory allocated for an char, referenced by a void pointer (which the function takes as an argument).
 */

void freechar(void* ptr);

#endif