#ifndef __PYTHON_LIST_H__

#define __PYTHON_LIST_H__

#include <stddef.h>

/**
 * Creates a struct named PythonList which elements are, a void pointer that saves the required data, and an integer that represents the proper type of said data
 */

typedef struct {
  void *value;
  int type;
} PythonList;

/**
 * Creates a PythonList list of size n
 */

PythonList* new_python_list (int n);

void free_element (PythonList element);

void free_python_list(PythonList *list, int n);

#endif