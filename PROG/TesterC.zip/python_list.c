#include <stdlib.h>
#include "python_list.h"
#include "free_type.h"

PythonList* new_python_list (int n) {
  return malloc(sizeof(PythonList)*n);
}

void free_element (PythonList element) {
  int type = element.type;
  (*FREE_FUNC[type])(element.value);
}

void free_python_list(PythonList *list, int n) {
  for (int i = 0; i < n; i++)
    free_element(list[i]);

  free(list);
}