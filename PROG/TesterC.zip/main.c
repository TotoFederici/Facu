#include <stdio.h>
#include <stdlib.h>
#include "free_type.h"
#include "print_type.h"
#include "read_type.h"
#include "python_list.h"

/**
 * Using indices for each of the types:
 * INT_TYPE -> 0
 * FLOAT_TYPE -> 1
 * CHAR_TYPE -> 2
 * STRING_TYPE -> 3
 */

int main() {
  PythonList *list;

  printf("Ingrese la cantidad de elementos:");
  int n;
  scanf("%d%*c", &n);

  list = new_python_list(n);

  for (int i = 0; i < n; i++) {
    printf("Ingrese el tipo del elemento (0 - 3): ");
    int type;
    scanf("%d%*c", &type);

    void *value = (*READ_FUNC[type])();

    list[i] = (PythonList){value,type}; //?????
  }

  printf("Los elementos de tu lista son:\n");
  for (int i = 0; i < n; i++) {
    int type = list[i].type;
    (*PRINT_FUNC[type])(list[i].value);
    printf("\n");
  }

  free_python_list(list, n);

  return 0;
}