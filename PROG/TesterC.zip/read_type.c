#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "read_type.h"

char buf[1024];

void* (*const READ_FUNC[])() = {&readint, &readfloat, &readchar, &readstr}; //(1)
// void (*const READ_FUNC)(void *) = malloc(sizeof(void *) * 4); //Equivalente
// a 1?

void* readint() {
  int *x = malloc(sizeof(int));
  scanf("%d%*c",x);
  return x;
}

void* readfloat() { 
  char *x = malloc(sizeof(float));
  scanf("%f%*c", (float *)x); //*c lee caracter y descarta
  return x;
}

void* readchar() {
  char *x = malloc(sizeof(char));
  scanf("%c",x);
  return x;
}

void* readstr() { 
  scanf("%[^\n]%*c", buf);
  int len = strlen(buf);
  char *x = malloc(sizeof(char)*(len+1));
  strcpy(x,buf);
  return x;
}