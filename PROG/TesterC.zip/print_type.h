#ifndef __PRINT_TYPE_H__

#define __PRINT_TYPE_H__

#include <stddef.h>

extern void (*const PRINT_FUNC[])(void*);

/**
 * Takes a void pointer, casts it to an int and shows it on screen
 */

void printint(void* ptr);

/**
 * Takes a void pointer, casts it to a float and shows it on screen
 */

void printfloat (void* ptr);

/**
 * Takes a void pointer, casts it to a char and shows it on screen
 */

void printchar (void* ptr);

/**
 * Takes a void pointer, casts it to a string and shows it on screen
 */

void printstr (void* ptr);

#endif