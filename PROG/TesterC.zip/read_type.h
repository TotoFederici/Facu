#ifndef __READ_TYPE_H__

#define __READ_TYPE_H__

#include <stddef.h>

extern void* (*const READ_FUNC[])();

/**
 * Reads an integer, allocates memory for it and returns a pointer to it.
 */
void* readint();

/**
 * Reads a float, allocates memory for it and returns a pointer to it.
 */
void* readfloat();

/**
 * Reads a single char, allocates memory for it and returns a pointer to it.
 */
void* readchar();

/**
 * Reads the line as a string, allocates memory for it and returns a pointer to it.
 */

void* readstr();

#endif