#include <stdio.h>
#include <stdlib.h>
#include "free_type.h"

void (*const FREE_FUNC[])(void*) = {&freeint, &freefloat, &freechar, &freestr};

void freeint (void* ptr) { free((int*)ptr); }
void freefloat (void* ptr) { free((float*)ptr); }
void freestr (void* ptr) { free((char*)ptr); }
void freechar (void* ptr) { freestr(ptr); }