#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "print_type.h"

/**
 * Creates a void pointer to constant array of functions which take a void pointer as an argument
 */
void (*const PRINT_FUNC[])(void*) = {&printint, &printfloat, &printchar, &printstr};

void printint (void* ptr) {
  printf("%d", *((int*)ptr));
}

void printfloat (void* ptr){
  printf("%lf", *((float*) ptr));
}

void printchar (void* ptr) {
  printf("%c", *((char*)ptr));
}

void printstr (void* ptr) {
  printf("%s",(char*)ptr);
}