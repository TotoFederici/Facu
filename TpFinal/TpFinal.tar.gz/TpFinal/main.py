from completar_frases import *
import sys

def main(nombre: str):
    predicciones(nombre)
    
main(sys.argv[1])